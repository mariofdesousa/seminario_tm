# Confira se o JAVA instalado em seu computador está atualizado. Se não estiver
# atualize antes de instalar os pacotes.

# Quando o JAVA estiver atualizado, retire o comentario (#) das linhas 6-12

# install.packages(c('tm', 'stringi','ggplot2','ggthemes','wordcloud',
#                   'RColorBrewer','plyr','stringr','topicmodels','portfolio',
#            'openNLP', 'qdap','SnowballC'),repos = "http://cran.r-project.org", 
#                 dependencies = c("Depends", "Imports", "Suggests"))

# install.packages('openNLPmodels.en', repos = "http://datacube.wu.ac.at/",
#                 type = "source")

library(twitteR)
library(httr)
library(tm)
library(wordcloud)
library(SnowballC)
library(dendextend)
library(qdap)
library(stringr)
library(plyr)
library(readr)
library(dplyr)
library(tidytext)
library(topicmodels)
library(ggplot2)
library(tidyr)
library(RWeka)


# key <- 	"PqRqHQo0jHDJfhtGBeDhZRjMr"
# secret <- "kuXDWmsPUriwiI46VHWje1It3ftBcjcR8oxEBjSYvgwvwgY5Ve"
# accesstoken <- "864574120180240385-bUmqx0eH3cCXqBxRUf6jvhnZwlvFQVu"
# tokensecret <- "vPWNWaVqxYljrm5fuwy29i3Ygwk5gc6YQ6DHF33hrctQL"

# setup_twitter_oauth(key, secret, accesstoken, tokensecret )
# Nao execute as funcoes marcadas abaixo para nao alterar a base de dados
# udemytweets1 <- searchTwitter("depression",n=1000)
# udemytweets2 <- searchTwitter("fired",n=1000)
# udemytweets3 <- searchTwitter("drugs",n=1000)
# udemytweets  <- rbind(udemytweets1,udemytweets2,udemytweets3)

# udemylist   <- sapply(udemytweets, function(x) x$getText())

# udemycorpus <- Corpus(VectorSource(udemylist))
# custom.stopwords <- c(stopwords('english'), 'lol', 'smh')
# udemycorpus = clean.corpus(udemycorpus)

# udemytdm <- TermDocumentMatrix(udemycorpus)

wordcloud(udemycorpus, min.freq = 15, scale = c(5,1), random.color = F,
          random.order = F, max.words = 30)









findFreqTerms(udemytdm, lowfreq = 10)
findAssocs(udemytdm, "adulto", 0.6)

dim(udemytdm)



udemy_m <- as.matrix(udemytdm)
term_frequency <- rowSums(udemy_m)
term_frequency
frequency <- freq_terms(udemycorpus, top = 10, at.least = 3, stopwords = "Top200Words")
frequency2 <- freq_terms(udemycorpus, top = 10, at.least = 3, stopwords = tm::stopwords("portuguese"))
plot(frequency2)

dist_freq <- dist(frequency)
dist_freq
hc <- hclust(dist_freq)
plot(hc)


tdm2 <- removeSparseTerms(udemytdm, sparse = 0.1)
tdm2
tdm_m <- as.matrix(tdm2)

tdm_df <- as.data.frame(tdm_m)

tweets_dist <- dist(tdm_df)

hc <- hclust(tweets_dist)

plot(hc)


hcd <- as.dendrogram(hc)

labels(hcd)

plot(hcd, main = "Better Dendrogram")

####################################################################
################    Rodney               ###########################
####################################################################

# Análise de tópicos

library(dplyr)
library(tidytext)
library(topicmodels)
library(ggplot2)
library(tidyr)


class(udemytdm)
tidy_data = tidy(udemytdm)
tidy_data
palavras_problema = c("c\xe2\x80","hell\xe2\x80","drink\xe2\x80","ي\xd8",
                      "httpstcoxcujkdekfs","httpstcobhtbienixw","foc\xe2\x80",
                      "drugs\xe2\x80","httpstc\xe2\x80","httpstcocjbetjm\xe2\x80",
                      "d\xe2\x80","addicted\xe2\x80")
tidy_data <- tidy_data %>% filter(!term %in% palavras_problema)
depre_dtm <- tidy_data %>% cast_dtm(document, term, count)


# aplicando a análise de tópicos
depre_lda <- LDA(depre_dtm, k = 2, control = list(seed = 1234))
depre_lda

# usando o tidy para extrair as probabilidades tópico/palavra
depre_topics <- tidy(depre_lda, matrix = "beta")
depre_topics

depre_top_terms <- depre_topics %>%
  group_by(topic) %>%
  top_n(20, beta) %>%
  ungroup() %>%
  arrange(topic, -beta)
depre_top_terms$term
depre_top_terms %>%
  mutate(term = reorder(term, beta)) %>%
  ggplot(aes(term, beta, fill = factor(topic))) +
  geom_col(show.legend = FALSE) +
  facet_wrap(~ topic, scales = "free") +
  coord_flip()

beta_spread <- depre_topics %>%
  mutate(topic = paste0("topic", topic)) %>%
  spread(topic, beta) %>%
  filter(topic1 > .001 | topic2 > .001) %>%
  mutate(log_ratio = log2(topic2 / topic1))
beta_spread

beta_spread %>%
  top_n(20,abs(log_ratio)) %>%
  mutate(term = reorder(term, log_ratio)) %>%
  ggplot(aes(term, log_ratio)) +
  geom_col(show.legend = FALSE) +
  coord_flip()

####################################################################
################    Mario                ###########################
####################################################################
# Analise de sentimentos
# 
library(stringr)
## dicionario de palavras relacionadas a repressao
#depressionwords <- read_csv("D:/Rgit/seminario_tm/seminario/depressionwords.csv")

# bancos de dados para análise de sentimentos
get_sentiments("afinn")
get_sentiments("bing")
nrc <- get_sentiments("nrc")
#############################################
#####         negative                   ####   
tweets_tidy_nostop <- tweets_data(udemytdm)

require(tibble)
library(lubridate)

tweets.df <- twListToDF(udemytweets)
tweets_tidy_df <- as_tibble(tweets.df)

replace_reg <- "https://t.co/[A-Za-z\\d]+|http://[A-Za-z\\d]+|&amp;|&lt;|&gt;|RT|https"
unnest_reg <- "([^A-Za-z_\\d#@']|'(?![A-Za-z_\\d#@]))"

mystopwords <- c(stop_words$word,"lol","haha")

tidy_tweets <- tweets_tidy_df %>% 
  filter(!str_detect(text, "^RT")) %>%
  mutate(text = str_replace_all(text, replace_reg, "")) %>%
  unnest_tokens(word, text, token = "regex", pattern = unnest_reg) %>%
  filter(!word %in% mystopwords,
         str_detect(word, "[a-z]"))

nrneg <- get_sentiments("nrc") %>% 
  filter(sentiment == "negative")

tidy_tweets %>%
  inner_join(nrneg) %>%
  count(word, sort = TRUE)%>%
  filter(n > 10) %>%
  mutate(word = reorder(word, n)) %>%
  ggplot(aes(word, n)) +
  geom_col() +
  xlab(NULL) +
  coord_flip()
#############################################
#####         sadness                    ####   
nrsad <- get_sentiments("nrc") %>% 
  filter(sentiment == "sadness")

tidy_tweets %>%
  inner_join(nrsad) %>%
  count(word, sort = TRUE) %>%
  filter(n > 10) %>%
  mutate(word = reorder(word, n)) %>%
  ggplot(aes(word, n)) +
  geom_col() +
  xlab(NULL) +
  coord_flip()
#############################################
#####         anger                      ####   
nrang <- get_sentiments("nrc") %>% 
  filter(sentiment == "anger")


tidy_tweets %>%
  inner_join(nrang) %>%
  count(word, sort = TRUE) %>%
  filter(n > 10) %>%
  mutate(word = reorder(word, n)) %>%
  ggplot(aes(word, n)) +
  geom_col() +
  xlab(NULL) +
  coord_flip() 
# A palavra suicidio aparece pela primeira vez com elevada
# frequencia
#############################################
#####         fear                       ####   
nrfear <- get_sentiments("nrc") %>% 
  filter(sentiment == "fear")

tidy_tweets %>%
  inner_join(nrfear) %>%
  count(word, sort = TRUE) %>%
  filter(n > 10) %>%
  mutate(word = reorder(word, n)) %>%
  ggplot(aes(word, n)) +
  geom_col() +
  xlab(NULL) +
  coord_flip() 
# A palavra suicidio aparece pela segunda vez 
#############################################
#####         disgust                    ####   
nrdisg <- get_sentiments("nrc") %>% 
  filter(sentiment == "disgust")

tidy_tweets %>%
  inner_join(nrdisg) %>%
  count(word, sort = TRUE) %>%
  filter(n > 5) %>%
  mutate(word = reorder(word, n)) %>%
  ggplot(aes(word, n)) +
  geom_col() +
  xlab(NULL) +
  coord_flip() #nao parece ter coisas relacionadas com suicidio
#############################################
#####         surprise                   ####   
nrsurp <- get_sentiments("nrc") %>% 
  filter(sentiment == "surprise")

tidy_tweets %>%
  inner_join(nrsurp) %>%
  count(word, sort = TRUE) %>%
  filter(n > 5) %>%
  mutate(word = reorder(word, n)) %>%
  ggplot(aes(word, n)) +
  geom_col() +
  xlab(NULL) +
  coord_flip() 
#nao parece ter coisas relacionadas com suicidio. 
#parece ter palavras em comum com disgust
#

#################################################################
################# Dicionario Bing               #################     
tweets_tidy_nostop <- tweets_data(udemytdm)

tweets_tidy_nostop %>%
  inner_join(get_sentiments("bing")) %>%
  count(index = line %/% 100, sentiment) %>%
  spread(sentiment, n, fill = 0) %>%
  mutate(sentiment = positive - negative) %>%
  ggplot(aes(index, sentiment)) +
  geom_col(show.legend = FALSE) 
### Elevada aparição de palavras negativas em grupos de 100 palavras

#################################################################
################# Dicionario afinn              #################     

afinn <- tweets_tidy_nostop %>% 
  inner_join(get_sentiments("afinn")) %>% 
  group_by(index = line %/% 100) %>% 
  summarise(sentiment = sum(score)) %>% 
  mutate(method = "AFINN")
#################################################################
################# Comparacao de dicionarios     #################     

# No dicionario nrc estamos contrastando palavras positivas e negativas

bing_and_nrc <- bind_rows(tweets_tidy_nostop %>% 
                            inner_join(get_sentiments("bing")) %>%
                            mutate(method = "Bing et al."),
                          tweets_tidy_nostop %>% 
                            inner_join(get_sentiments("nrc") %>% 
                                         filter(sentiment %in% c("positive", 
                                                                 "negative"))) %>%
                            mutate(method = "NRC")) %>%
  count(method, index = line %/% 100, sentiment) %>%
  spread(sentiment, n, fill = 0) %>%
  mutate(sentiment = positive - negative)

bind_rows(afinn, 
          bing_and_nrc) %>%
  ggplot(aes(index, sentiment, fill = method)) +
  geom_col(show.legend = FALSE) +
  facet_wrap(~method, ncol = 1, scales = "free_y") 

### Todos os dicionários captam elevada quantidade de palavras negativas

####
#### Bigramas
#### 
tidy_tweets_big <- tweets_tidy_df %>% 
  filter(!str_detect(text, "^RT")) %>%
  mutate(text = str_replace_all(text, replace_reg, "")) %>%
  unnest_tokens(word, text, token = "ngrams",n=2) %>%
  filter(!word %in% mystopwords,
         str_detect(word, "[a-z]"))

tidy_tweets_big %>%
  count(word, sort = TRUE)

bigrams_separated <- tidy_tweets_big %>%
  separate(word, c("word1", "word2"), sep = " ")

bigrams_separated %>%
  filter(word1 == "depression") %>%
  count(word1, word2, sort = TRUE)

AFINN <- get_sentiments("afinn")

# We can then examine the most frequent words that were preceded by “not” and 
# were associated with a sentiment.
depression_words <- bigrams_separated %>%
  filter(word1 == "depression") %>%
  inner_join(AFINN, by = c(word2 = "word")) %>%
  count(word2, score, sort = TRUE) %>%
  ungroup()

depression_words

depression_words %>%
  mutate(contribution = n * score) %>%
  arrange(desc(abs(contribution))) %>%
  head(20) %>%
  mutate(word2 = reorder(word2, contribution)) %>%
  ggplot(aes(word2, n * score, fill = n * score > 0)) +
  geom_col(show.legend = FALSE) +
  xlab("Words preceded by \"depression\"") +
  ylab("Sentiment score * number of occurrences") +
  coord_flip()


drugs_words <- bigrams_separated %>%
  filter(word1 == "drugs") %>%
  inner_join(AFINN, by = c(word2 = "word")) %>%
  count(word2, score, sort = TRUE) %>%
  ungroup()
drugs_words

drugs_words %>%
  mutate(contribution = n * score) %>%
  arrange(desc(abs(contribution))) %>%
  head(20) %>%
  mutate(word2 = reorder(word2, contribution)) %>%
  ggplot(aes(word2, n * score, fill = n * score > 0)) +
  geom_col(show.legend = FALSE) +
  xlab("Words preceded by \"drugs\"") +
  ylab("Sentiment score * number of occurrences") +
  coord_flip()

### Rede de palavras

library(igraph)

bigrams_filtered <- bigrams_separated %>%
  filter(!word1 %in% stop_words$word) %>%
  filter(!word2 %in% stop_words$word)

bigram_counts <- bigrams_filtered %>% 
  count(word1, word2, sort = TRUE)

bigram_graph <- bigram_counts %>%
  filter(n > 5) %>%
  graph_from_data_frame()

bigram_graph

library(ggraph)

set.seed(2017)

ggraph(bigram_graph, layout = "fr") +
  geom_edge_link() +
  geom_node_point() +
  geom_node_text(aes(label = name), vjust = 1, hjust = 1)

set.seed(2016)

a <- grid::arrow(type = "closed", length = unit(.15, "inches"))

ggraph(bigram_graph, layout = "fr") +
  geom_edge_link(aes(edge_alpha = n), show.legend = FALSE,
                 arrow = a, end_cap = circle(.07, 'inches')) +
  geom_node_point(color = "lightblue", size = 5) +
  geom_node_text(aes(label = name), vjust = 1, hjust = 1) +
  theme_void()

#Counting and correlating pairs of words with the widyr package
library(widyr)
word_cors <- tidy_tweets %>%
  group_by(word) %>%
  filter(n() >= 20) %>%
  pairwise_cor(word, screenName, sort = TRUE)

word_cors

#Palavras correlacionadas com depression
word_cors %>%
  filter(item1 %in% c("depression", "drugs","health")) %>%
  group_by(item1) %>%
  top_n(8) %>%
  ungroup() %>%
  mutate(item2 = reorder(item2, correlation)) %>%
  ggplot(aes(item2, correlation)) +
  geom_bar(stat = "identity") +
  facet_wrap(~ item1, scales = "free") +
  coord_flip()
################
## Wordclouds
library(reshape2)
tidy_tweets %>%
  inner_join(get_sentiments("bing")) %>%
  count(word, sentiment, sort = TRUE) %>%
  acast(word ~ sentiment, value.var = "n", fill = 0) %>%
  comparison.cloud(colors = c("red", "blue"),
                   max.words = 100)
