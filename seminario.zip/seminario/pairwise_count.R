pairwise_count <- function(tbl, item, feature, wt = NULL, ...) {
  pairwise_count_(tbl,
                  col_name(substitute(item)),
                  col_name(substitute(feature)),
                  wt = col_name(substitute(wt)),
                  ...)
}



pairwise_count_ <- function(tbl, item, feature, wt = NULL, ...) {
  if (is.null(wt)) {
    func <- squarely_(function(m) m %*% t(m), sparse = TRUE, ...)
    wt <- "..value"
  } else {
    func <- squarely_(function(m) m %*% t(m > 0), sparse = TRUE, ...)
  }
  
  tbl %>%
    distinct_(.dots = c(item, feature), .keep_all = TRUE) %>%
    mutate(..value = 1) %>%
    func(item, feature, wt) %>%
    rename(n = value)
}