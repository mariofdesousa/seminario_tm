## Esta função retorna o texto limpo


tweets_data <- function(data){
  
  tweets_tidy = tidy(data)
  tweets_tidy <- data_frame(line=1:31256,text = as.character(tweets_tidy$term)) %>%  
    unnest_tokens(word, text)
  
  ### Retirando as stop_words com caracteres estranhos
  tweets_tidy_nostop <- tweets_tidy %>%
    anti_join(stop_words) %>%
    filter(!str_detect(word, "[0-9]"),
           word != "ã",
           word != "â",
           word != "câ",
           word != "dont",
           word != "isnt", 
           word != "httpstcobhtbienixw",
           word != "shes",
           word != "yall",
           word != "focâ",
           word != "hellâ€",
           word != "â€™m",
           word != "kâ€",
           word != "httâ",
           word != "httpstcoqgxwqdâ€",
           word != "httpstcoegosvyrxzâ€",
           word != "dâ€",
           word != "hellâ",
           word != "httpstcozqâ",
           word != "httpstâ",
           word != "fridayfeelingâ",
           word != "htâ",
           word != "coalâ",
           word != "donâ",
           word != "kâ",
           word != "donâ",
           word != "httpsâ",
           word != "dâ",
           word != "adverseâ",
           word != "pmâ",
           word != "fâ",
           word != "indiaâ",
           word != "fitâ",
           word != "pâ",
           word != "httpstcoâ",
           word != "hâ",
           word != "httpâ",
           word != "httpstcondxxtnyvosâ",
           word != "exâ",
           word != "alltâ",
           word != "lasâ",
           word != "httpstcâ",
           word != "lasâ",
           word != "augustalsinaâ",
           word != "matterâ",
           word != "conjuncâ",
           word != "httpstcowquâ",
           word != "happyâ",
           word != "songâ",
           word != "wâ",
           !str_detect(word, "[a-z]_"),
           !str_detect(word, ":"),
           #word != "bar",
           #word != "emph",
           !str_detect(word, "textless"))
  
  return(tweets_tidy_nostop)
  
}